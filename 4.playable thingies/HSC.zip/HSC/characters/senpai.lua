function onCreate()
  makeAnimatedLuaSprite('Sparks', 'weeb/Sparkle_Assets')
  addLuaSprite('Sparks', true)
  addAnimationByPrefix('Sparks', 'anim', 'SPARKLEESS', 24, true)
  scaleObject('Sparks', 6,6)
  setScrollFactor('Sparks', 0.5,0.5);
  setProperty('Sparks.antialiasing', false);
end