function onCreate()
  setProperty('bgGirls.visible', false);
end
   
