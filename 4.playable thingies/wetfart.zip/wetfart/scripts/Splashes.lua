function onCreatePost()
	
		makeAnimatedLuaSprite('Left', 'BFSplashes', 650, -40)
		addAnimationByPrefix('Left', 'LSplash', 'note splash purple', 24, false)
		addLuaSprite('Left', true)
		setObjectCamera('Left', 'hud')
		scaleObject('Left', 0.85, 0.85);
		setProperty('Left.alpha', 0)
		makeAnimatedLuaSprite('Down', 'BFSplashes', 750, -40)
		addAnimationByPrefix('Down', 'DSplash', 'note splash blue', 24, false)
		addLuaSprite('Down', true)
		setObjectCamera('Down', 'hud')
		scaleObject('Down', 0.85, 0.85);
		setProperty('Down.alpha', 0)
		makeAnimatedLuaSprite('Up', 'BFSplashes', 865, -40)
		addAnimationByPrefix('Up', 'USplash', 'note splash green', 24, false)
		addLuaSprite('Up', true)
		setObjectCamera('Up', 'hud')
		scaleObject('Up', 0.85, 0.85);
		setProperty('Up.alpha', 0)
		makeAnimatedLuaSprite('Right', 'BFSplashes', 980, -40)
		addAnimationByPrefix('Right', 'RSplash', 'note splash red', 24, false)
		addLuaSprite('Right', true)
		setObjectCamera('Right', 'hud')
		scaleObject('Right', 0.85, 0.85);
		setProperty('Right.alpha', 0)
	
end

function opponentNoteHit(id, direction, noteType, isSustainNote)
	
		if direction == 0 then
			setProperty('Left.alpha', 1)
			objectPlayAnimation('Left', 'LSplash', true)
			runTimer('LSpl', 0.16)
		elseif direction == 1 then
			setProperty('Down.alpha', 1)
			objectPlayAnimation('Down', 'DSplash', true)
			runTimer('DSpl', 0.16)
		elseif direction == 2 then
			setProperty('Up.alpha', 1)
			objectPlayAnimation('Up', 'USplash', true)
			runTimer('USpl', 0.16)
		elseif direction == 3 then
			setProperty('Right.alpha', 1)
			objectPlayAnimation('Right', 'RSplash', true)
			runTimer('RSpl', 0.16)
		
	end
end
function onTimerCompleted(tag, loops, loopsLeft)
	if tag == 'LSpl' then
		setProperty('Left.alpha', 0)
	elseif tag == 'DSpl' then
		setProperty('Down.alpha', 0)
	elseif tag == 'USpl' then
		setProperty('Up.alpha', 0)
	elseif tag == 'RSpl' then
		setProperty('Right.alpha', 0)
	end
end