function onCreatePost()

  --Goodbye Pysch UI
  
  setProperty('scoreTxt.visible',false)
  setProperty('botplayTxt.visible', false)
  setProperty('showComboNum', false) 
  setProperty('showRating', false)  
end