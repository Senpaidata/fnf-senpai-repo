function onCreate()
  --background 
    
	makeLuaSprite('bg','weeb/weebSky', -1000,-520)
    addLuaSprite('bg',false)
    scaleObject('bg', 12, 12)
    setScrollFactor('bg', 0.1, 0.1);
	
	makeLuaSprite('bgSky','weeb/weebSky',-200,0)
    addLuaSprite('bgSky',false)
    scaleObject('bgSky', 6, 6)
    setScrollFactor('bgSky', 0.1, 0.1);
	doTweenX("move", "bgSky", -430, 0, "linear")
    
    makeLuaSprite('bgSchool','weeb/weebSchool',-200,0)
    addLuaSprite('bgSchool',false)
    scaleObject('bgSchool', 6, 6)
    setScrollFactor('bgSchool', 0.6, 0.90);
    
    makeLuaSprite('bgStreet','weeb/weebStreet',-200,0)
    addLuaSprite('bgStreet',false)
    scaleObject('bgStreet', 6, 6)
    setScrollFactor('bgStreet', 0.95, 0.95);
    
    makeLuaSprite('fgTrees','weeb/weebTreesBack',-200,0)
    addLuaSprite('fgTrees',false)
    scaleObject('fgTrees', 6, 6)
    setScrollFactor('fgTrees', 0.9, 0.9);
	
	makeLuaSprite('fgTreesRes','weeb/weebTreesRestored',-330,0)
    addLuaSprite('fgTreesRes',false)
    scaleObject('fgTreesRes', 6, 6)
    setScrollFactor('fgTreesRes', 0.9, 0.9);
	
	makeLuaSprite('fgTreesRes2','weeb/weebTreesRestored',-100,0)
    addLuaSprite('fgTreesRes2',false)
    scaleObject('fgTreesRes2', 6, 6)
    setScrollFactor('fgTreesRes2', 0.9, 0.9);
	setProperty('fgTreesRes2.flipX', true);
    
    makeAnimatedLuaSprite('bgTrees','weeb/weebTrees',-780,-1000)
    scaleObject('bgTrees', 6, 6)
    addAnimationByPrefix('bgTrees','treeLoop','tree_',24,true)
    addLuaSprite('bgTrees',false)
    objectPlayAnimation('bgTrees','treeLoop',false)
	
	makeAnimatedLuaSprite('treeLeaves','weeb/petals',-200,-40)
    scaleObject('treeLeaves', 6, 6)
    addAnimationByPrefix('treeLeaves','fall','PETALS ALL',24,true)
    addLuaSprite('treeLeaves',false)
    objectPlayAnimation('treeLeaves','fall',false)
	
	
	
	
	makeAnimatedLuaSprite('bgGirls1','weeb/bgGirls2', -150,-115)
    scaleObject('bgGirls1', 6, 6)
    addAnimationByPrefix('bgGirls1','anim','BG girls group',36,true)
    addLuaSprite('bgGirls1',false)
    objectPlayAnimation('bgGirls1','anim',false)
	
	makeAnimatedLuaSprite('bgGirls2','weeb/bgGirls2alt', 380,-115)
    scaleObject('bgGirls2', 6, 6)
    addAnimationByPrefix('bgGirls2','anim','BG girls group',36,true)
    addLuaSprite('bgGirls2',false)
    objectPlayAnimation('bgGirls2','anim',false)
	
	makeAnimatedLuaSprite('bgGirls3','weeb/bgGirls2', 910,-115)
    scaleObject('bgGirls3', 6, 6)
    addAnimationByPrefix('bgGirls3','anim','BG girls group',36,true)
    addLuaSprite('bgGirls3',false)
    objectPlayAnimation('bgGirls3','anim',false)
	
	
	
	
	
	
    
    
	
	
	
    setProperty('bg.antialiasing', false);
    setProperty('bgSky.antialiasing', false);
	setProperty('bgSchool.antialiasing', false);
	setProperty('bgStreet.antialiasing', false);
	setProperty('fgTrees.antialiasing', false);
	setProperty('bgTrees.antialiasing', false);
	setProperty('treeLeaves.antialiasing', false);
	setProperty('bgGirls1.antialiasing', false);
	setProperty('bgGirls2.antialiasing', false);
	setProperty('bgGirls3.antialiasing', false);
	setProperty('fgTreesRes.antialiasing', false);
	setProperty('fgTreesRes2.antialiasing', false);
	
	
	
	
	
	

   
   end
   
