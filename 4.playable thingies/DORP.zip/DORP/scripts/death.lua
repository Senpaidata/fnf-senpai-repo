function onCreate()
	setPropertyFromClass('GameOverSubstate', 'characterName', 'senpai-dead');
	end