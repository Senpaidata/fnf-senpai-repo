function onCreate()
  --background 
    makeLuaSprite('bgSkyD1','weeb/weebSkyD1',-200,0)
    addLuaSprite('bgSkyD1',false)
    scaleObject('bgSkyD1', 6, 6)
    setScrollFactor('bgSkyD1', 0.1, 0.1);
    
    makeLuaSprite('bgSchoolD1','weeb/weebSchoolD1',-200,0)
    addLuaSprite('bgSchoolD1',false)
    scaleObject('bgSchoolD1', 6, 6)
    setScrollFactor('bgSchoolD1', 0.6, 0.90);
    
    makeLuaSprite('bgStreetD1','weeb/weebStreetD1',-200,0)
    addLuaSprite('bgStreetD1',false)
    scaleObject('bgStreetD1', 6, 6)
    setScrollFactor('bgStreetD1', 0.95, 0.95);
    
    makeLuaSprite('fgTreesD1','weeb/weebTreesBackD1',-200,0)
    addLuaSprite('fgTreesD1',false)
    scaleObject('fgTreesD1', 6, 6)
    setScrollFactor('fgTreesD1', 0.9, 0.9);
	
	makeLuaSprite('fgTreesResD1','weeb/weebTreesRestored',-330,0)
    addLuaSprite('fgTreesResD1',false)
    scaleObject('fgTreesResD1', 6, 6)
    setScrollFactor('fgTreesResD1', 0.9, 0.9);
	
	makeLuaSprite('fgTreesRes2D1','weeb/weebTreesRestored',-100,0)
    addLuaSprite('fgTreesRes2D1',false)
    scaleObject('fgTreesRes2D1', 6, 6)
    setScrollFactor('fgTreesRes2D1', 0.9, 0.9);
	setProperty('fgTreesRes2D1.flipX', true);
    
    makeAnimatedLuaSprite('bgTreesD1','weeb/weebTreesD1',-780,-1000)
    scaleObject('bgTreesD1', 6, 6)
    addAnimationByPrefix('bgTreesD1','treeLoop','tree_',24,true)
    addLuaSprite('bgTreesD1',false)
    objectPlayAnimation('bgTreesD1','treeLoop',false)
	
	makeAnimatedLuaSprite('bgGirlsD1','weeb/bgFreaksHellamad',-100,190)
    scaleObject('bgGirlsD1', 6, 6)
    addAnimationByPrefix('bgGirlsD1','anim','BG fangirls dissuaded',24,true)
    addLuaSprite('bgGirlsD1',false)
    objectPlayAnimation('bgGirlsD1','anim',false)
    
    makeAnimatedLuaSprite('bgGuysD1','weeb/bgGuys',-350,190)
    scaleObject('bgGuysD1', 6, 6)
    addAnimationByPrefix('bgGuysD1','anim','BG fangirls dissuaded',24,true)
    addLuaSprite('bgGuysD1',false)
    objectPlayAnimation('bgGuysD1','anim',false)
    
    makeAnimatedLuaSprite('gffnf','characters/gfPixel',250,160)
    scaleObject('gffnf', 6, 6)
    addAnimationByPrefix('gffnf','anim','GF IDLE',24,true)
    addLuaSprite('gffnf',false)
    objectPlayAnimation('gffnf','anim',false)
    
    
    
    
	
	
	
    
    setProperty('bgSkyD1.antialiasing', false);
	setProperty('bgSchoolD1.antialiasing', false);
	setProperty('bgStreetD1.antialiasing', false);
	setProperty('fgTreesD1.antialiasing', false);
	setProperty('bgTreesD1.antialiasing', false);
	setProperty('treeLeavesD1.antialiasing', false);
	setProperty('bgGirlsD1.antialiasing', false);
	setProperty('bgGuysD1.antialiasing', false);
	setProperty('gffnf.antialiasing', false);
	setProperty('fgTreesResD1.antialiasing', false);
	setProperty('fgTreesRes2D1.antialiasing', false);
	
	
	
	
	
	
	
	

   
   end
   
