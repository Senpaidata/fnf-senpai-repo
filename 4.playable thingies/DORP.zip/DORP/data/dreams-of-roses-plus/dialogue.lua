-- CODE BY SHADOW MARIO, DO NOT FORGET TO CREDIT
-- MAYBE ASK FOR HIS PERMISSION BEFORE YOU USE THIS (I DID)
allowStart = false
dialogueShit = {}
dialogueSenpai = {}
dialogueSenpaiAngry = {}
dialogueSenpaiAngry2 = {}
dialogueSenpaiSad = {}
dialogueSenpaiGotit = {}
dialogueSenpaiHuh = {}
dialogueSenpaiIdea = {}
dialogueSenpaiScritchScratch = {}
dialogueSenpaiThink = {}
dialogueSenpaiGotit2 = {}
dialogueSenpaiGotit3 = {}
dialogueSenpaiNoPurple = {}
dialogueSenpaiMadStill = {}
dialogueSenpaiStill = {}
dialogueSenpaiAngerHands = {}
dialogueSenpaiHands = {}
dialogueSenpaiHorny = {}
dialogueBF = {}
dialogueBFANGRY = {}
dialogueBFUHH = {}
--DONT FORGET TO ADD THE PORTRAIT ABOVE AS WELL (ITS LIKE THE JSON OF THE PORTRAIT)

function onStartCountdown()
	if not allowStart and isStoryMode then
		doReturn = false
		startSenpaiCutscene('roses', 'roses');
		playSound('ANGRY_TEXT_BOX', 1, true)
		doReturn = true
		
		if doReturn then
			setProperty('boyfriend.stunned', true)
			setProperty('inCutscene', true)
			return Function_Stop
		end
	end
	return Function_Continue
end

function onSongStart()
	if isStoryMode then
		setProperty('fakeN1.offset.y', -62)
		setProperty('fakeN2.offset.y', -62)
	else
		setProperty('fakeN1.offset.y', -67)
		setProperty('fakeN2.offset.y', -72)
	end
end

dialogueLineName = ''
dialogueLineType = ''
dialogueSound = 'pixelText'
dialogueSoundClick = 'clickText'

curDialogue = 0

dialogueOpened = false
dialogueStarted = false
dialogueEnded = false
dialogueGone = false
targetText = 'blah blah coolswag'
function onTimerCompleted(tag, loops, loopsLeft)
	if tag == 'start senpai dialogue' then
		allowStart = true
		addLuaSprite('bgFade', true)
		makeAnimatedLuaSprite('portraitLeft', 'weeb/senpaiPortrait', -20, 40)
		pixelThingie('portraitLeft', 5.4, true)
		addAnimationByPrefix('portraitLeft', 'enter', 'Senpai Portrait Enter', 24, false)
		setProperty('portraitLeft.visible', false)
		
		makeAnimatedLuaSprite('portraitLeft2', 'weeb/senpaiMad', -20, 40)
		pixelThingie('portraitLeft2', 5.4, true)
		addAnimationByPrefix('portraitLeft2', 'enter', 'Senpai Portrait Enter', 24, false)
		setProperty('portraitLeft2.visible', false)
		
		makeAnimatedLuaSprite('portraitLeft3', 'weeb/senpaiAngry', -20, 40)
		pixelThingie('portraitLeft3', 5.4, true)
		addAnimationByPrefix('portraitLeft3', 'enter', 'Senpai Portrait Enter', 24, false)
		setProperty('portraitLeft3.visible', false)
		
		makeAnimatedLuaSprite('portraitLeft4', 'weeb/senpaiSad', -20, 40)
		pixelThingie('portraitLeft4', 5.4, true)
		addAnimationByPrefix('portraitLeft4', 'enter', 'Senpai Portrait Enter', 24, false)
		setProperty('portraitLeft4.visible', false)
		
		makeAnimatedLuaSprite('portraitLeft5', 'weeb/SenpaiGotit', 150, 105);
		pixelThingie('portraitLeft5', 5.4, true);
		addAnimationByPrefix('portraitLeft5', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft5.visible', false);
		
		makeAnimatedLuaSprite('portraitLeft6', 'weeb/SenpaiHuh', 150, 130);
		pixelThingie('portraitLeft6', 5.4, true);
		addAnimationByPrefix('portraitLeft6', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft6.visible', false);
		
		makeAnimatedLuaSprite('portraitLeft7', 'weeb/Senpaiidea', 150, 105);
		pixelThingie('portraitLeft7', 5.4, true);
		addAnimationByPrefix('portraitLeft7', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft7.visible', false);
		
		makeAnimatedLuaSprite('portraitLeft8', 'weeb/Senpaiscritchstracth', 140, 110);
		pixelThingie('portraitLeft8', 5.4, true);
		addAnimationByPrefix('portraitLeft8', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft8.visible', false);
		
		makeAnimatedLuaSprite('portraitLeft9', 'weeb/SenpaiThink', 150, 105);
		pixelThingie('portraitLeft9', 5.4, true);
		addAnimationByPrefix('portraitLeft9', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft9.visible', false);
		
		makeAnimatedLuaSprite('portraitLeft10', 'weeb/SenpaiGotit2', 150, 105);
		pixelThingie('portraitLeft10', 5.4, true);
		addAnimationByPrefix('portraitLeft10', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft10.visible', false);
		
		makeAnimatedLuaSprite('portraitLeft11', 'weeb/SenpaiGotit3', 150, 105);
		pixelThingie('portraitLeft11', 5.4, true);
		addAnimationByPrefix('portraitLeft11', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft11.visible', false);
		
		makeAnimatedLuaSprite('portraitLeft12', 'weeb/senpaiPortraitMadnopurpl', 150, 125);
		pixelThingie('portraitLeft12', 5.4, true);
		addAnimationByPrefix('portraitLeft12', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft12.visible', false);
		
		makeAnimatedLuaSprite('portraitLeft13', 'weeb/senpaiPortraitMadStill', 150, 125);
		pixelThingie('portraitLeft13', 5.4, true);
		addAnimationByPrefix('portraitLeft13', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft13.visible', false);
		
		makeAnimatedLuaSprite('portraitLeft14', 'weeb/senpaiPortraitStill', 150, 125);
		pixelThingie('portraitLeft14', 5.4, true);
		addAnimationByPrefix('portraitLeft14', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft14.visible', false);
		
		makeAnimatedLuaSprite('portraitLeft15', 'weeb/senpaiAngerHands', 150, 125);
		pixelThingie('portraitLeft15', 5.4, true);
		addAnimationByPrefix('portraitLeft15', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft15.visible', false);
		
		makeAnimatedLuaSprite('portraitLeft16', 'weeb/senpaiHands', 150, 125);
		pixelThingie('portraitLeft16', 5.4, true);
		addAnimationByPrefix('portraitLeft16', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft16.visible', false);
		
		makeAnimatedLuaSprite('portraitLeft17', 'weeb/senpaiHorny', 150, 125);
		pixelThingie('portraitLeft17', 5.4, true);
		addAnimationByPrefix('portraitLeft17', 'enter', 'Senpai Portrait Enter', 24, false);
		setProperty('portraitLeft17.visible', false);
		
		makeAnimatedLuaSprite('portraitRight', 'weeb/bfschool', -20, 40)
		pixelThingie('portraitRight', 5.4, true)
		addAnimationByPrefix('portraitRight', 'enter', 'Portrait Enter instance', 24, false)
		setProperty('portraitRight.visible', false)
		
		makeAnimatedLuaSprite('portraitRight2', 'weeb/bfangry', -20, 40)
		pixelThingie('portraitRight2', 5.4, true)
		addAnimationByPrefix('portraitRight2', 'enter', 'Portrait Enter instance', 24, false)
		setProperty('portraitRight2.visible', false)
		
		makeAnimatedLuaSprite('portraitRight3', 'weeb/bfwhat', -20, 40)
		pixelThingie('portraitRight3', 5.4, true)
		addAnimationByPrefix('portraitRight3', 'enter', 'Portrait Enter instance', 24, false)
		setProperty('portraitRight3.visible', false)
		
		----------------------------------------------------------------------------------------------------------------------------------------------------PASTE PORTRAITS ABOVE
		
		if dialogueLineType == 'thorns' then
			spiritImage = 'weeb/spiritFaceForward'
			makeLuaSprite('spiritUgly', spiritImage, 320, 170)
			pixelThingie('spiritUgly', 6, false)
		end
		
		if dialogueLineType == 'thorns' then
			boxImage = 'weeb/pixelUI/dialogueBox-evil'
			
			makeAnimatedLuaSprite('dialogueBox', boxImage, -20, 45)
			addAnimationByPrefix('dialogueBox', 'normalOpen', 'Spirit Textbox spawn', 24, false)
			addAnimationByIndices('dialogueBox', 'normal', 'Spirit Textbox spawn instance 1', '11', 24)
		elseif dialogueLineType == 'roses' then
			boxImage = 'weeb/pixelUI/dialogueBox-pixel'
			
			makeAnimatedLuaSprite('dialogueBox', 'weeb/pixelUI/dialogueBox-pixel', -20, 45)
			addAnimationByPrefix('dialogueBox', 'normalOpen', 'Text Box Appear', 24, false)
			addAnimationByIndices('dialogueBox', 'normal', 'Text Box Appear instance 1', '4', 24)
		else
			makeAnimatedLuaSprite('dialogueBox', 'weeb/pixelUI/dialogueBox-pixel', -20, 45)
			addAnimationByPrefix('dialogueBox', 'normalOpen', 'Text Box Appear', 24, false)
			addAnimationByIndices('dialogueBox', 'normal', 'Text Box Appear instance 1', '4', 24)
		end
		pixelThingie('dialogueBox', 5.4, true)
		
		screenCenter('dialogueBox', 'x')
		screenCenter('portraitLeft', 'x')
		
		handImage = 'weeb/pixelUI/hand_textbox'
		
		makeLuaSprite('handSelect', handImage, 1042, 590)
		pixelThingie('handSelect', 5.4, true)
		setProperty('handSelect.visible', false)
		
		makeLuaText('dropText', '', screenWidth * 0.6, 242, 502)
		setTextFont('dropText', 'pixel.otf')
		setTextColor('dropText', 'D89494')
		setTextBorder('dropText', 0, 0)
		setTextSize('dropText', 32)
		setTextAlignment('dropText', 'left')
		addLuaText('dropText')
		
		makeLuaText('swagDialogue', '', screenWidth * 0.6, 240, 500)
		setTextFont('swagDialogue', 'pixel.otf')
		setTextColor('swagDialogue', '3F2021')
		setTextBorder('swagDialogue', 0, 0)
		setTextSize('swagDialogue', 32)
		setTextAlignment('swagDialogue', 'left')
		addLuaText('swagDialogue')
		
		if dialogueLineType == 'thorns' then
			setTextColor('dropText', '000000')
			setTextColor('swagDialogue', 'FFFFFF')
		end
		
	elseif tag == 'remove black' then
		setProperty('senpaiBlack.alpha', getProperty('senpaiBlack.alpha') - 0.15)
	elseif tag == 'increase bg fade' then
		newAlpha = getProperty('bgFade.alpha') + (1 / 5) * 0.7
		if newAlpha > 0.7 then
			newAlpha = 0.7
		end
		setProperty('bgFade.alpha', newAlpha)
	elseif tag == 'add dialogue letter' then
		setTextString('swagDialogue', string.sub(targetText, 0, (loops - loopsLeft)))
		playSound(dialogueSound, 0.8)
		
		if loopsLeft == 0 then
			--debugPrint('Text finished!')
			setProperty('handSelect.visible', true)
			dialogueEnded = true
		end
	elseif tag == 'end dialogue thing' then
		newAlpha = loopsLeft / 5
		cancelTimer('increase bg fade')
		setProperty('bgFade.alpha', newAlpha * 0.7)
		setProperty('dialogueBox.alpha', newAlpha)
		setProperty('swagDialogue.alpha', newAlpha)
		setProperty('dropText.alpha', newAlpha)
		setProperty('handSelect.alpha', newAlpha)
	elseif tag == 'start countdown thing' then
		allowStart = true
		removeLuaSprite('bgFade')
		removeLuaSprite('dialogueBox')
		removeLuaSprite('dialogueBox2')
		removeLuaSprite('handSelect')
		removeLuaText('swagDialogue')
		removeLuaText('dropText')
		setProperty('inCutscene', false)
		setProperty('boyfriend.stunned', false)
		startCountdown()
		dialogueGone = true
		
		removeLuaSprite('spiritUgly')
	elseif tag == 'make senpai visible' then
		setProperty('senpaiEvil.alpha', getProperty('senpaiEvil.alpha') + 0.15)
		if loopsLeft == 0 then
			playSound('Senpai_Dies')
			objectPlayAnimation('senpaiEvil', 'die')
			runTimer('start flash', 3.2)
		end
	elseif tag == 'start flash' then
		cameraFade('other', 'FFFFFF', 1.6, true)
	end
end

isEnding = false
function onUpdate(elapsed)
	if dialogueGone then
		return
	end
	
	if getProperty('dialogueBox.animation.curAnim.name') == 'normalOpen' and getProperty('dialogueBox.animation.curAnim.finished') then
		objectPlayAnimation('dialogueBox', 'normal')
		dialogueOpened = true
	end
	
	if dialogueOpened and not (dialogueStarted) then
		startDialogueThing()
		objectPlayAnimation('portraitLeft', 'enter', true)
		dialogueStarted = true
	end
	
	if mouseClicked('left') then
		if dialogueEnded then
			curDialogue = curDialogue + 1
			if curDialogue > table.maxn(dialogueShit) then
				if not isEnding then
					removeLuaSprite('portraitLeft')
					removeLuaSprite('portraitLeft2')
					removeLuaSprite('portraitLeft3')
					removeLuaSprite('portraitLeft4')
					removeLuaSprite('portraitLeft5')
					removeLuaSprite('portraitLeft6')
					removeLuaSprite('portraitLeft7')
					removeLuaSprite('portraitLeft8')
					removeLuaSprite('portraitLeft9')
					removeLuaSprite('portraitLeft10')
					removeLuaSprite('portraitLeft11')
					removeLuaSprite('portraitLeft12')
					removeLuaSprite('portraitLeft13')
					removeLuaSprite('portraitLeft14')
					removeLuaSprite('portraitLeft15')
					removeLuaSprite('portraitLeft16')
					removeLuaSprite('portraitLeft17')
					removeLuaSprite('portraitRight')
					removeLuaSprite('portraitRight2')
					removeLuaSprite('portraitRight3')
					runTimer('end dialogue thing', 0.2, 5)
					runTimer('start countdown thing', 1.5)
					soundFadeOut(nil, 1.5)
					isEnding = true
					playSound(dialogueSoundClick, 0.8)
				end
			else
				startDialogueThing()
				playSound(dialogueSoundClick, 0.8)
			end
		elseif dialogueStarted then
			cancelTimer('add dialogue letter')
			onTimerCompleted('add dialogue letter', string.len(targetText), 0)
			playSound(dialogueSoundClick, 0.8)
		end
	end
	setTextString('dropText', getTextString('swagDialogue'))
end

function startDialogueThing()
	reloadDialogue()
	runTimer('add dialogue letter', 0.04, string.len(targetText))
end

----------------------------------------------------------------------------------------------------------------------------------------------------PORTRAIT CODE 1 BELOW

function reloadDialogue()
    curCharacterSenpai = dialogueSenpai[curDialogue]
	curCharacterSenpaiAngry = dialogueSenpaiAngry[curDialogue]
	curCharacterSenpaiAngry2 = dialogueSenpaiAngry2[curDialogue]
	curCharacterSenpaiSad = dialogueSenpaiSad[curDialogue]
	curCharacterSenpaiGotit = dialogueSenpaiGotit[curDialogue]
	curCharacterSenpaiHuh = dialogueSenpaiHuh[curDialogue]
	curCharacterSenpaiIdea = dialogueSenpaiIdea[curDialogue]
	curCharacterSenpaiScritchScratch = dialogueSenpaiScritchScratch[curDialogue]
	curCharacterSenpaiThink = dialogueSenpaiThink[curDialogue]
	curCharacterSenpaiGotit2 = dialogueSenpaiGotit2[curDialogue]
	curCharacterSenpaiGotit3 = dialogueSenpaiGotit3[curDialogue]
	curCharacterSenpaiNoPurple = dialogueSenpaiNoPurple[curDialogue]
	curCharacterSenpaiMadStill = dialogueSenpaiMadStill[curDialogue]
	curCharacterSenpaiStill = dialogueSenpaiStill[curDialogue]
	curCharacterSenpaiAngerHands = dialogueSenpaiAngerHands[curDialogue]
	curCharacterSenpaiHands = dialogueSenpaiHands[curDialogue]
	curCharacterSenpaiHorny = dialogueSenpaiHorny[curDialogue]
	curCharacterBF = dialogueBF[curDialogue]
	curCharacterBFANGRY = dialogueBFANGRY[curDialogue]
	curCharacterBFUHH = dialogueBFUHH[curDialogue]
	targetText = dialogueShit[curDialogue]
	
	----------------------------------------------------------------------------------------------------------------------------------------------------PORTRAIT CODE 1 ABOVE
	
	setTextString('dropText', '')
	setTextString('swagDialogue', '')
	setProperty('handSelect.visible', false)
	dialogueEnded = false
	
	
	----------------------------------------------------------------------------------------------------------------------------------------------------PORTRAIT CODE 2 BELOW
	
	if curCharacterSenpai then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
        setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		if getProperty('portraitLeft.visible') == false then
			setProperty('portraitLeft.visible', true)
		end
		objectPlayAnimation('portraitLeft', 'enter')
		
		
	elseif curCharacterSenpaiAngry then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		
		if getProperty('portraitLeft2.visible') == false then
			setProperty('portraitLeft2.visible', true)
		end
		objectPlayAnimation('portraitLeft2', 'enter')
		
		
	elseif curCharacterSenpaiAngry2 then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		
		if getProperty('portraitLeft3.visible') == false then
			setProperty('portraitLeft3.visible', true)
		end
		objectPlayAnimation('portraitLeft3', 'enter')
		
		
	elseif curCharacterSenpaiSad then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		
		if getProperty('portraitLeft4.visible') == false then
			setProperty('portraitLeft4.visible', true)
		end
		objectPlayAnimation('portraitLeft4', 'enter')
		
		elseif curCharacterSenpaiGotit then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		setProperty('dialogueBox.visible', true)
		if getProperty('portraitLeft5.visible') == false then
			setProperty('portraitLeft5.visible', true)
		end
		objectPlayAnimation('portraitLeft5', 'enter')
		
		elseif curCharacterSenpaiHuh then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		setProperty('dialogueBox.visible', true)
		if getProperty('portraitLeft6.visible') == false then
			setProperty('portraitLeft6.visible', true)
		end
		objectPlayAnimation('portraitLeft6', 'enter')
		
		elseif curCharacterSenpaiIdea then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		setProperty('dialogueBox.visible', true)
		if getProperty('portraitLeft7.visible') == false then
			setProperty('portraitLeft7.visible', true)
		end
		objectPlayAnimation('portraitLeft7', 'enter')
		
		elseif curCharacterSenpaiScritchScratch then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('dialogueBox.visible', true)
		setProperty('portraitRight3.visible', false)
		if getProperty('portraitLeft8.visible') == false then
			setProperty('portraitLeft8.visible', true)
		end
		objectPlayAnimation('portraitLeft8', 'enter')
		
		elseif curCharacterSenpaiThink then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		setProperty('dialogueBox.visible', true)
		if getProperty('portraitLeft9.visible') == false then
			setProperty('portraitLeft9.visible', true)
		end
		objectPlayAnimation('portraitLeft9', 'enter')
		
		elseif curCharacterSenpaiGotit2 then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		setProperty('dialogueBox.visible', true)
		if getProperty('portraitLeft10.visible') == false then
			setProperty('portraitLeft10.visible', true)
		end
		objectPlayAnimation('portraitLeft10', 'enter')
		
		elseif curCharacterSenpaiGotit3 then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		setProperty('dialogueBox.visible', true)
		if getProperty('portraitLeft11.visible') == false then
			setProperty('portraitLeft11.visible', true)
		end
		objectPlayAnimation('portraitLeft11', 'enter')
		
		elseif curCharacterSenpaiNoPurple then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		setProperty('dialogueBox.visible', true)
		if getProperty('portraitLeft12.visible') == false then
			setProperty('portraitLeft12.visible', true)
		end
		objectPlayAnimation('portraitLeft12', 'enter')
		
		elseif curCharacterSenpaiMadStill then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		setProperty('dialogueBox.visible', true)
		if getProperty('portraitLeft13.visible') == false then
			setProperty('portraitLeft13.visible', true)
		end
		objectPlayAnimation('portraitLeft13', 'enter')
		
		elseif curCharacterSenpaiStill then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		setProperty('dialogueBox.visible', true)
		if getProperty('portraitLeft14.visible') == false then
			setProperty('portraitLeft14.visible', true)
		end
		objectPlayAnimation('portraitLeft14', 'enter')
		
		elseif curCharacterSenpaiAngerHands then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		setProperty('dialogueBox.visible', true)
		if getProperty('portraitLeft15.visible') == false then
			setProperty('portraitLeft15.visible', true)
		end
		objectPlayAnimation('portraitLeft15', 'enter')
		
		elseif curCharacterSenpaiHands then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		setProperty('dialogueBox.visible', true)
		if getProperty('portraitLeft16.visible') == false then
			setProperty('portraitLeft16.visible', true)
		end
		objectPlayAnimation('portraitLeft16', 'enter')
		
		elseif curCharacterSenpaiHorny then
		setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
		setProperty('portraitRight.visible', false)
		setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
		setProperty('dialogueBox.visible', true)
		if getProperty('portraitLeft17.visible') == false then
			setProperty('portraitLeft17.visible', true)
		end
		objectPlayAnimation('portraitLeft17', 'enter')
		
	elseif curCharacterBF then
	setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
	setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
	if getProperty('portraitRight.visible') == false then
		setProperty('portraitRight.visible', true)
		end
		if getProperty('dialogueBox.visible') == false then
			setProperty('dialogueBox.visible', true)
	
	objectPlayAnimation('portraitRight', 'enter', true)
	end
    elseif curCharacterBFANGRY then
	setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
	setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
	if getProperty('portraitRight2.visible') == false then
		setProperty('portraitRight2.visible', true)
		end
		if getProperty('dialogueBox.visible') == false then
			setProperty('dialogueBox.visible', true)
	
	objectPlayAnimation('portraitRight2', 'enter', true)
	end
    elseif curCharacterBFUHH then
	setProperty('portraitLeft.visible', false)
        setProperty('portraitLeft2.visible', false)
        setProperty('portraitLeft3.visible', false)
        setProperty('portraitLeft4.visible', false)
        setProperty('portraitLeft5.visible', false)
        setProperty('portraitLeft6.visible', false)
        setProperty('portraitLeft7.visible', false)
        setProperty('portraitLeft8.visible', false)
        setProperty('portraitLeft9.visible', false)
        setProperty('portraitLeft10.visible', false)
        setProperty('portraitLeft11.visible', false)
        setProperty('portraitLeft12.visible', false)
        setProperty('portraitLeft13.visible', false)
        setProperty('portraitLeft14.visible', false)
        setProperty('portraitLeft15.visible', false)
        setProperty('portraitLeft16.visible', false)
        setProperty('portraitLeft17.visible', false)
	setProperty('portraitRight2.visible', false)
		setProperty('portraitRight3.visible', false)
	if getProperty('portraitRight3.visible') == false then
		setProperty('portraitRight3.visible', true)
		end
		if getProperty('dialogueBox.visible') == false then
			setProperty('dialogueBox.visible', true)
	
	objectPlayAnimation('portraitRight3', 'enter', true)
	end
end
end

----------------------------------------------------------------------------------------------------------------------------------------------------PORTRAIT CODE 2 ABOVE

function startSenpaiCutscene(dialogueType, type)
	makeLuaSprite('bgFade', nil, -200, -200)
	makeGraphic('bgFade', screenWidth * 1.3, screenHeight * 1.3, 'B3DFD8')
	setProperty('bgFade.alpha', 0)
	setScrollFactor('bgFade', 0, 0)
	setObjectCamera('bgFade', 'hud')
	runTimer('increase bg fade', 0.83, 5)
	
	
	
	if type == 'senpai' then
		makeLuaSprite('senpaiBlack', nil, -100, -100)
		makeGraphic('senpaiBlack', screenWidth * 2, screenHeight * 2, '000000')
		setScrollFactor('senpaiBlack', 0, 0)
		addLuaSprite('senpaiBlack', true)
		runTimer('remove black', 0.3, 7)
	elseif type == 'thorns' then
		makeLuaSprite('senpaiBlack', nil, -100, -100)
		makeGraphic('senpaiBlack', screenWidth * 2, screenHeight * 2, 'FF1B31')
		setScrollFactor('senpaiBlack', 0, 0)
		addLuaSprite('senpaiBlack', true)
		
		assetName = 'weeb/senpaiCrazy'
		
		makeAnimatedLuaSprite('senpaiEvil', assetName, 0, 0)
		addAnimationByIndices('senpaiEvil', 'idle', 'Senpai Pre Explosion instance 1', '0', 24)
		addAnimationByPrefix('senpaiEvil', 'die', 'Senpai Pre Explosion', 24, false)
		scaleObject('senpaiEvil', 6, 6)
		setScrollFactor('senpaiEvil', 0, 0)
		screenCenter('senpaiEvil')
		setProperty('senpaiEvil.x', getProperty('senpaiEvil.x') + 300)
		setProperty('senpaiEvil.antialiasing', false)
		setProperty('senpaiEvil.alpha', 0)
		addLuaSprite('senpaiEvil', true)
		
		setProperty('camHUD.visible', false)
		runTimer('make senpai visible', 0.3, 7)
	end
	
	----------------------------------------------------------------------------------------------------------------------------------------------------DIALOGUE CODE BELOW
	
	dialogueLineName = dialogueType
	dialogueLineType = type
	if dialogueType == 'roses' then
		dialogueShit[0] = 'boyfriend...'
		dialogueSenpaiAngry[0] = true
		dialogueShit[1] = 'what the fuck is he doing here?!'
		dialogueSenpaiAngry[1] = true
        dialogueShit[2] = 'dude'
		dialogueBFANGRY[2] = true
        dialogueShit[3] = 'how many times do i have to tell you'
		dialogueBFANGRY[3] = true
        dialogueShit[4] = 'he doesnt mean harm'
		dialogueBFANGRY[4] = true
        dialogueShit[5] = 'hes a precious cinnamon bun' 
		dialogueBF[5] = true
        dialogueShit[6] = 'deadass serious rn dude?'
		dialogueSenpaiAngry[6] = true
        dialogueShit[7] = 'hes got a curse that kills people'
		dialogueSenpaiAngry[7] = true
        dialogueShit[8] = 'i dont wanna come close to that...'
		dialogueSenpaiAngry[8] = true
        dialogueShit[9] = '...thing'
		dialogueSenpaiAngry[9] = true
        dialogueShit[10] = 'the worst part is...'
		dialogueSenpaiAngry[10] = true
        dialogueShit[11] = 'youre bringing him to the school'
		dialogueSenpaiAngry[11] = true
        dialogueShit[12] = 'nothing bad is gonna happen man'
		dialogueBFANGRY[12] = true
        dialogueShit[13] = 'just relax...'
	    dialogueBF[13] = true
        dialogueShit[14] = 'i will'
	    dialogueSenpaiAngry[14] = true
        dialogueShit[15] = 'WHEN YOU GET HIM THE FUCK AWAY FROM SCHOOL'
	    dialogueSenpaiAngerHands[15] = true
        dialogueShit[16] = 'oh boy'
	    dialogueBFANGRY[16] = true
        dialogueShit[17] = 'here we go again'
	    dialogueBFANGRY[17] = true
		
	end
	
	----------------------------------------------------------------------------------------------------------------------------------------------------DIALOGUE CODE ABOVE
	
	timerTime = 2 --stupid name
	if type == 'thorns' then
		timerTime = 9.2
	end
	runTimer('start senpai dialogue', timerTime)
end

function pixelThingie(tag, scale, doUpdateHitbox)
	if doUpdateHitbox then
		scaleObject(tag, scale, scale)
	else
		setProperty(tag..'.scale.x', scale)
		setProperty(tag..'.scale.y', scale)
	end
	setScrollFactor(tag, 0, 0)
	setObjectCamera(tag, 'hud')
	setProperty(tag..'.antialiasing', false)
	addLuaSprite(tag, true)
end