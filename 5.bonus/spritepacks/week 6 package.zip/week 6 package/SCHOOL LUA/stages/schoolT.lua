function onCreate()
  --background 
    
	makeLuaSprite('thornsschool','weeb/animatedEvilSchool',-950,-1050)
    addLuaSprite('thornsschool',false)
    scaleObject('thornsschool', 6, 6)
	addAnimationByPrefix('thornsschool','anim','background 2 instance',24,true)
    addLuaSprite('thornsschool',false)
    objectPlayAnimation('thornsschool','anim',false)
	
	setProperty('thornsschool.antialiasing', false);
    
end
   
