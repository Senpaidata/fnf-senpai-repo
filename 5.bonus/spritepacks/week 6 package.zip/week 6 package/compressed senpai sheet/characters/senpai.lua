function onCreate()
  makeAnimatedLuaSprite('Sparks', 'characters/Sparkle_Assets')
  addLuaSprite('Sparks', true)
  addAnimationByPrefix('Sparks', 'anim', 'SPARKLEESS', 24, true)
  scaleObject('Sparks', 6,6)
  setScrollFactor('Sparks', 0.8,0.8);
  setProperty('Sparks.antialiasing', false);
end