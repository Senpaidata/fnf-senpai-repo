function onCreate()
 removeLuaSprite('Sparks')
end