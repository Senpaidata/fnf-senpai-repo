basically a package containing all the stuff that can be used to make a original senpay mod 
enjoy