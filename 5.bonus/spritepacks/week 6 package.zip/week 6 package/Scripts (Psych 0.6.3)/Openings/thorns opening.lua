function onCreate()
if not isStoryMode then
playMusic('LunchboxScary')
end
end
function onCurStep()
if curStep == 1 then
CancelMusic('LunchboxScary')
end
end
