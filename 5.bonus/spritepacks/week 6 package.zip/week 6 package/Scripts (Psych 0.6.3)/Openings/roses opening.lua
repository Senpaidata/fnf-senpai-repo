function onCreate()
if not isStoryMode then
playSound('ANGRY_TEXT_BOX')
end
end
