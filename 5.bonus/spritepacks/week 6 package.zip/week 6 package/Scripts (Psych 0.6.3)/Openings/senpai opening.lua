function onCreate()
if not isStoryMode then
playMusic('Lunchbox')
end
end
function onCurStep()
if curStep == 1 then
CancelMusic('Lunchbox')
end
end
