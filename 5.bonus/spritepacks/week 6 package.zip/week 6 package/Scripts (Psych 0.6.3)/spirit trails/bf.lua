function onCreatePost()
	addHaxeLibrary('FlxTrail', 'flixel.addons.effects') -- imports FlxTrail
	runHaxeCode('spiritos = new FlxTrail(game.boyfriend, null, 4, 24, 0.3, 0.069)')
	--code lmao
end
function onStepHit()
	if curStep ==  then
	runHaxeCode('game.addBehindBF(spiritos)')
	end
	--activation lmao
	if curStep ==  then
	runHaxeCode('game.remove(spiritos)') 
	end
	--deactivation lmao
end