function onCreatePost()
	addHaxeLibrary('FlxTrail', 'flixel.addons.effects') -- imports FlxTrail
	runHaxeCode([[
		game.addBehindDad(new FlxTrail(game.dad, null, 4, 24, 0.3, 0.069)); // adds a trail behind the opponent
	]])
end