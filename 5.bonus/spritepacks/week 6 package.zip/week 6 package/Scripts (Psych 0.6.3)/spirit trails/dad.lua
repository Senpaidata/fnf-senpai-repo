function onCreatePost()
	addHaxeLibrary('FlxTrail', 'flixel.addons.effects') -- imports FlxTrail
	runHaxeCode('spiritos = new FlxTrail(game.dad, null, 4, 24, 0.3, 0.069)')
	--code lmao
end
function onStepHit()
	if curStep ==  then
	runHaxeCode('game.addBehindDad(spiritos)')
	end
	--activation lmao
	if curStep ==  then
	runHaxeCode('game.remove(spiritos)') 
	end
	--deactivation lmao
end