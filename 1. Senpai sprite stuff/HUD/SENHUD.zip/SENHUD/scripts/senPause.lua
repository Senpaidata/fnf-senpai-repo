-- Senpai Pause Menu
-- Made by Held_der_Zeit (Gamebanana) / @held_der_zeit (Discord)
-- Made for @senpaidata7521 (Discord)




tweentime = 0.3
numSize = 45 --text size
txtColor = "3F2021" --text color

-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
-- !!! DON'T CHANGE ANYTHING PAST THIS POINT !!!
--      unless you know what you are doing
-- !!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

wideness = 600 --txt width
pauseX = 325 --pause text x pos
pauseY = 265 --pause text y pos

distY = 95 --y distance between texts

cursOffX = 40 --cursor x offset for custom menu
cursOffY = 20 --cursor y offset for custom menu

pointOffX = 10  --new, length based offset

HUD_PATH = "pause/" --for hud bg images

--menuObjects = {"bg", "Resume", "Retry", "Exit", "pointer"}
menuTexts = {"Resume", "Retry", "Exit"}
menuSprites = {"pointer", "pauseBox"}

curOption = 1 --selected option

hasPauseMusic = true





function onCreatePost()
	--pauseSong = getPropertyFromClass('PauseSubState', "pauseMusic")
	if getPropertyFromClass('ClientPrefs', "pauseMusic") ~= "None" then
		-- mus = getPropertyFromClass('ClientPrefs', "pauseMusic")
		-- muses = stringSplit(string.lower(mus), " ")
		-- pamus = muses[1]

		-- for i=2,#muses do
		-- 	pamus = pamus.."-"..muses[i]
		-- end

		-- pauseSong = currentModDirectory.."music/"..pamus

		pauseSong = "SET_SOUND_HERE"

		hasPauseMusic = true
	end
	


    --options and their functions
    MENU_OPTIONS = {
        [1] = function()
            closeCustomSubstate() --resume
        end,
        [2] = function()
            restartSong() --restart song
        end, 
        [3] = function()
            exitSong() --exit song
        end
    }
end


function onPause()
	openCustomSubstate('Senpai Pause', true)
	return Function_Stop
end

------------------------

--------- custom pause substate shit

------------------------



function onCustomSubstateCreate(name)
    if name == "Senpai Pause" then
		--debugPrint(pauseSong)
		--sprites = {"bg", "left", "right", "Resume", "Retry", "Exit", "pointer"}


		--sprites

		-- makeLuaSprite('bg', "", 0, 0) -- dark bg
		-- makeGraphic('bg', screenWidth, screenHeight, '000000')
		-- setProperty('bg.alpha', 0.4)
		-- setObjectCamera('bg', 'other')
		-- --setProperty('bg.alpha', 0)
		-- addLuaSprite('bg')

		makeLuaSprite('pauseBox', HUD_PATH..'box', 250, 150) -- pause box
		setProperty('pauseBox.alpha', 1)
		setObjectCamera('pauseBox', 'other')
		scaleObject('pauseBox', 4, 4)
		addLuaSprite('pauseBox')


        --texts
        makeLuaText("Resume", "RESUME", wideness, pauseX, pauseY)
        makeLuaText("Retry", "RESTART", wideness, pauseX, getProperty("Resume.y")+ distY)
        makeLuaText("Exit", "EXIT", wideness, pauseX, getProperty("Retry.y")+ distY)

		for j = 1, #(menuTexts) do
			setTextFont(menuTexts[j], 'pixel.otf')
			setTextSize(menuTexts[j], numSize)
			setTextColor(menuTexts[j], txtColor)
			setObjectCamera(menuTexts[j], "other")

			--setProperty(menuTexts[j]'.antialiasing', false);

			addLuaText(menuTexts[j])
		end



        --cursor
        makeLuaSprite("pointer", HUD_PATH.."arrow", getProperty("Resume.x")-cursOffX, getProperty("Resume.y")+cursOffY)
        --makeGraphic("pointer", 50, 50, "EBC334")
        setObjectCamera("pointer", "other")
		scaleObject('pointer', 4, 4)
        addLuaSprite("pointer")



		for k = 1, #(menuSprites) do
			setProperty(menuSprites[k]..'.antialiasing', false);
		end

		--not required really
		-- for i = 1, #(menuObjects) do
		-- 	setProperty(menuObjects[i]".alpha",0)
		-- end

		if hasPauseMusic then
			--playMusic(getPropertyFromClass('PauseSubState', "pauseMusic"), 0.7, true)
			playSound(pauseSong, 0.7,'pauseMusic')
			--soundFadeIn("pauseMusic", 1, 0, 0.7)
		end
    end
end

function onCustomSubstateUpdate(name, elapsed)
    if name == "Senpai Pause" then

        --cursor selection
        if keyJustPressed('accept') then
            MENU_OPTIONS[curOption]()
        elseif keyJustPressed('up') then
            curOption = curOption - 1
        elseif keyJustPressed('down') then
            curOption = curOption + 1
        end
        
        if curOption > #(MENU_OPTIONS) then
            curOption = 1
        elseif curOption < 1 then
            curOption = #(MENU_OPTIONS)
        end

        --to stop unneccessary calls and sets
        if getProperty("pointer.y") ~= getProperty(menuTexts[curOption]..".y") + cursOffY then
            setProperty("pointer.y", getProperty(menuTexts[curOption]..".y") + cursOffY)
        end
		if getProperty("pointer.x") ~= (getProperty(menuTexts[curOption]..".x") + string.len(menuTexts[curOption])*pointOffX)  then-- + cursOffX then
            setProperty("pointer.x", getProperty(menuTexts[curOption]..".x") + string.len(menuTexts[curOption])*pointOffX ) -- + cursOffX)
			--debugPrint(string.len(menuTexts[curOption]))
        end
    end
end

function onCustomSubstateDestroy(name)
    if name == "Senpai Pause" then
        for i = 1, #(menuTexts) do
            removeLuaText(menuTexts[i], false)
        end

		for i = 1, #(menuSprites) do
            removeLuaSprite(menuSprites[i], false)
        end
        --removeLuaSprite("pointer", false)
		stopSound("pauseMusic")
    end
end

function onSoundFinished(tag)
	playSound(pauseSong, 0.7, 'pauseMusic') -- loop song
end
